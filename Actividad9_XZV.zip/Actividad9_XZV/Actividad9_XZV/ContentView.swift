//
//  ContentView.swift
//  Actividad9_XZV
//
//  Created by Ximena Zenteno on 24/10/21.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        Text("Hello, world!")
            .padding()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
