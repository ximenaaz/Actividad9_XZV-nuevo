//
//  Actividad9_XZVApp.swift
//  Actividad9_XZV
//
//  Created by Ximena Zenteno on 24/10/21.
//

import SwiftUI

@main
struct Actividad9_XZVApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
